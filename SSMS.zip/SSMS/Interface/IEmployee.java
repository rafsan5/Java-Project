package Interface;
public interface IEmployee {
	int getEmployeeId();
	String getEmployeeName();
	String getEmployeeGender();
	double getEmployeeSalary();
	void show();
}